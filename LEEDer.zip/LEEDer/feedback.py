import os
import logging
import openai
from docx import Document
import PyPDF2  # For handling PDF files
import json

from leed_utils import get_leed_data 

# Set up logging
logging.basicConfig(level=logging.DEBUG)

# Set your API key (replace 'your_openai_api_key' with your actual API key)
openai.api_key = 'your_openai_api_key'

def get_feedback(user_input=None, file_path=None, rubrics=None, leed_scores=None):
    """
    Generates feedback for the user's input or uploaded file based on provided rubrics.
    Returns the feedback text, a dictionary of scores, and the raw feedback text from the AI.
    """
    # Get the content from the file or user input
    if file_path:
        try:
            if file_path.endswith('.docx'):
                doc = Document(file_path)
                file_text = '\n'.join([para.text for para in doc.paragraphs])
            elif file_path.endswith('.pdf'):
                with open(file_path, 'rb') as file:
                    reader = PyPDF2.PdfReader(file)
                    file_text = ''
                    for page in reader.pages:
                        extracted_text = page.extract_text()
                        if extracted_text:
                            file_text += extracted_text
            else:
                return "Unsupported file type.", {}, ""
            
            if not file_text.strip():
                return "The file is empty.", {}, ""
            prompt_text = file_text
        except Exception as e:
            logging.exception("Error reading file:")
            return f"Error reading file: {e}", {}, ""
    elif user_input:
        prompt_text = user_input
    else:
        return "No input provided.", {}, ""
    
    if len(prompt_text.strip()) < 100:
        return "Your writing is too short to get meaningful feedback. Could you please provide more details?", {}, ""
    
    # Determine content type (LEED Narrative or Not)
    content_check_prompt = (
        f"Based on the content of the following text, determine whether it is a LEED Narrative. "
        f"If it is a LEED Narrative, respond 'LEED Narrative'. "
        f"If it is not related to LEED Narrative, respond 'This is not related to LEED Narrative.'.\n\n"
        f"Text:\n{prompt_text}"
    )

    try:
        content_type_response = openai.ChatCompletion.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are an assistant that classifies text into 'General Writing' or 'LEED Narrative'."},
                {"role": "user", "content": content_check_prompt}
            ],
            temperature=0.0,
        )
        content_type = content_type_response['choices'][0]['message']['content'].strip().lower()
    except Exception as e:
        logging.exception("Error during content type determination:")
        return f"Error during content type determination: {e}", {}, ""

    # Generate feedback prompt based on content type
    if "leed narrative" in content_type:
        content_message = "This passage is identified as part of a LEED Narrative."

        # Get the latest LEED Rubric data
        leed_rubric_data = get_leed_data()

        # Determine if total score meets the requirement
        total_score = leed_scores.get('total_score', 0) if leed_scores else 0
        if total_score < 40:
            pass_message = f"Total score is {total_score}. The total score is less than 40 and does not meet the requirement."
        else:
            pass_message = f"Total score is {total_score}. Pass!"

        # Generate feedback prompt, instructing AI to include scores
        rubrics_text = format_leed_rubrics(leed_rubric_data)

        feedback_prompt = (
            f"{content_message}\n\n{pass_message}\n\n"
            f"Please provide detailed feedback based on the following LEED Rubrics.\n"
            f"For each rubric, please follow this format exactly, including all line breaks and spacing for readability:\n\n"
            f"[Rubric Title]\n\n"
            f"**Score:** X/Y\n\n"
            f"- Bullet point feedback.\n"
            f"- Bullet point feedback.\n"
            f"- Bullet point feedback.\n\n"
            f"**Example:**\n\n"
            f"LEED Certification Achievement\n\n"
            f"**Score:** 2/3\n\n"
            f"- The narrative partially demonstrates the project's LEED certification potential.\n"
            f"- More details on prerequisites are needed.\n\n"
            f"Please follow this format exactly.\n\n"
            f"Here are the LEED Rubrics:\n\n{rubrics_text}\n\n"
            f"Here is the user's text for evaluation:\n\n{prompt_text}\n\n"
        )
    else:
        content_message = "This passage is not related to LEED Narrative."
        return "This passage is not related to LEED Narrative."

    # Generate feedback
    try:
        feedback_response = openai.ChatCompletion.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are a very strict and experienced writing expert who provides detailed feedback. Remember, students need instructors to point out problems with their writing so that they can revise and improve their abilities, rather than giving them false praise."},
                {"role": "user", "content": feedback_prompt}
            ],
            temperature=0.7,
        )
        feedback_text = feedback_response['choices'][0]['message']['content'].strip()
    except Exception as e:
        logging.exception("Error during feedback generation:")
        return f"Error during feedback generation: {e}", {}, ""

    logging.debug("Feedback Text:\n%s", feedback_text)

    # Extract scores from feedback using AI
    if "leed narrative" in content_type:
        scores = extract_scores(feedback_text, leed_rubric_data)
    else:
        # For General Writing, extract scores if applicable
        scores = extract_scores(feedback_text, parse_rubrics(rubrics))

    final_feedback = f"{content_message}\n\n{feedback_text}"

    return final_feedback, scores, feedback_text

def format_leed_rubrics(leed_rubric_data):
    rubrics_text = ""
    for rubric in leed_rubric_data:
        rubric_name = rubric.get('name')
        scoring_criteria = rubric.get('scoringCriteria', [])
        total_points = max([crit.get('points', 0) for crit in scoring_criteria])

        rubrics_text += f"{rubric_name} (Total Points: {total_points})\n"
        rubrics_text += "Scoring Criteria:\n"
        for criterion in scoring_criteria:
            points = criterion.get('points')
            description = criterion.get('description')
            rubrics_text += f"  - {points} Points: {description}\n"
        rubrics_text += "\n"
    return rubrics_text

def extract_scores(feedback_text, rubric_data):

    # Prepare the list of rubric names
    if isinstance(rubric_data, list):
        rubrics_list = [rubric.get('name') for rubric in rubric_data]
    else:
        rubrics_list = [rubric.get('title') for rubric in rubric_data]

    rubrics_text = "\n".join(rubrics_list)

    prompt = f"""
The following is feedback text that includes scores for various rubrics:

{feedback_text}

Please extract the scores for each rubric listed below and return them in **valid JSON format**.

Rubrics:
{rubrics_text}

The JSON format should be exactly:
{{
    "LEED Certification Achievement": {{"score": X, "total": Y}},
    "Reflection of Credit Requirements": {{"score": X, "total": Y}},
    "Formatting: Credit Names and Points Claimed": {{"score": X, "total": Y}},
    "Realistic and Detailed Implementation of Credits": {{"score": X, "total": Y}},
    "Grammar, Structure, and Clarity": {{"score": X, "total": Y}}
}}

- Do not alter or reformat the rubric titles.
- Return them EXACTLY as listed above.
- Return ONLY the JSON object and NOTHING else.
- The JSON must start with "{" and end with "}".
- If you cannot provide a valid JSON exactly as above, return an empty JSON object: {{}}.
"""

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.0,
        )
        json_text = response['choices'][0]['message']['content'].strip()

        # First  check whether it starts with { and ends with }
        if not (json_text.startswith("{") and json_text.endswith("}")):
            logging.error("AI did not return a valid JSON object, or returned extra text.")
            return {}

        scores = json.loads(json_text)

    except Exception as e:
        logging.exception("Error during score extraction:")
        scores = {}

    return scores
def parse_rubrics(rubrics_text):
    """
    Parses the rubrics text provided by the user into a list of rubric dictionaries.
    This is necessary to extract scores for general writing rubrics.
    """
    rubrics = []
    # Split the rubrics by two newlines (assuming rubrics are separated by double newlines)
    rubric_entries = rubrics_text.strip().split('\n\n')
    for entry in rubric_entries:
        lines = entry.strip().split('\n')
        if lines:
            title = lines[0].strip()
            # Assuming total points are not provided, but we can set a default
            rubrics.append({
                "title": title,
                "total_points": 1  # Default total points; adjust as needed
            })
    return rubrics
